import java.util.LinkedList;

public class Polynomial
{
    private LinkedList<Term> polyList;

    //default constructor
    public Polynomial()
    {
        this.polyList = new LinkedList();
    }

    //full constructor
    public Polynomial(Polynomial polynomial)
    {
        this.polyList = new LinkedList();

        if (polynomial != null)
        {
            for (int i = 0; i < polynomial.getTotalTerms(); i++)
            {
                polyList.add(new Term(polynomial.getTerm(i)));
            }
        }
    }

    //add method that adds two polynomials with the help of the addTerm method
    public void add(Polynomial polynomial)
    {
        for (int i = 0; i < polynomial.getTotalTerms(); i++)
        {
            this.addTerm(polynomial.getTerm(i));
        }
    }

    //method that removes a term at a specific index
    public Term remove(int index)
    {
            Term temp = new Term(this.getTerm(index));
            this.polyList.remove(index);
            return temp;
    }

    //getters and setters
    public Term getTerm(int index)
    {
        return new Term(this.polyList.get(index));
    }

    //method to that returns the total number of terms in a polynomial
    public int getTotalTerms()
    {
        return this.polyList.size();
    }


    //toString method to display the polynomial to the user
    @Override
    public String toString() {
        String polyTerm;
        if (this.polyList == null || this.polyList.size() == 0)
        {
            polyTerm = "0";
        }
        else
        {
            polyTerm = "";

        for (int i = 0; i < polyList.size(); i++) {
            Term term = polyList.get(i);
            polyTerm += term.toString();
        }

        if (polyTerm.charAt(0) == '+') {
            polyTerm = polyTerm.substring(1);
        }

    }
        return polyTerm;
    }

    //method that adds two terms
    public void addTerm(Term other)
    {
        Term initialTerm, termCurrent, termNext, sum;
        int index;

        //if no terms
        if (this.polyList.size() == 0)
        {
            this.polyList.add(other);
        }

        //if only one term is present
        else if (this.polyList.size() == 1)
        {
            initialTerm = polyList.get(0);

            //if other greater
            if (other.compareTo(initialTerm) == 1)
            {
                polyList.add(0, other);
            }

            //if other same
            else if (other.compareTo(initialTerm) == 0)
            {
                sum = other.addition(initialTerm);
                if (sum != null)
                {
                    polyList.set(0, sum);
                }
                else
                {
                    polyList.remove(0);
                }
            }
            else
            {
                polyList.add(other);
            }
        }
        else
        {
            //if more than one term is present
            for (int i = 0; i < this.getTotalTerms() - 1; i++)
            {
                termCurrent = this.getTerm(i);
                termNext = this.getTerm(i + 1);

                //if other is greater than the current term
                if (other.compareTo(termCurrent) == 1)
                {
                    polyList.add(i, other);
                    return;
                }

                // else if term to Add Exponent matches current term's exponent
                else if (other.compareTo(termCurrent) == 0)
                {
                    sum = other.addition(termCurrent);
                    if (sum != null)
                    {
                        polyList.set(i, sum);
                    }
                    else
                    {
                        polyList.remove(i);
                    }
                    return;
                }

                //if other is less than current but greater than next term
                if (other.compareTo(termCurrent) == -1
                        && other.compareTo(termNext) == 1)
                {

                    polyList.add(i + 1, other);
                    return;
                }
            }

            index = this.getTotalTerms() - 1;
            initialTerm = this.getTerm(index);

            //if other is same as the initial term at the last position
            if (other.compareTo(initialTerm) == 0)
            {
                sum = other.addition(initialTerm);
                if (sum != null)
                {
                    polyList.set(index, sum);
                }
                else
                {
                    polyList.remove(index);
                }
            }
            else
            {
                polyList.add(other);
            }
        }
    }

    //method that clears the polynomial
    public void clear()
    {
        this.polyList.clear();
    }
}